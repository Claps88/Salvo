package salvo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository repository) {
		return (args) -> {
			// save a couple of customers
			Player p1 = new Player("jack@gmail.com");
			Player p2 = new Player("frank@gmail.com");
			Player p3 = new Player("miky@gmail.com");
			repository.save(p1);
			repository.save(p2);
			repository.save(p3);
		};
	}
}
